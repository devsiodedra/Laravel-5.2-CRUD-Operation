<?php $__env->startSection('title'); ?>
<?php echo e($product->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<?php echo Form::open([
	'method' => 'delete',
	'route' => ['product.destroy',$product->id]
	]); ?>

<h2><?php echo e($product->name); ?></h2>
<h3><?php echo e($product->price); ?></h3>

<a href="<?php echo e(route('product.edit',$product->id)); ?>">Edit</a>

<?php echo Form::submit('Delete'); ?>

<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>