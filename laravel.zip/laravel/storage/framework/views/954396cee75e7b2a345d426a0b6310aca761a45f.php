<?php $__env->startSection('title'); ?>
	All Products
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<?php foreach($products as $p): ?>
<?php echo e($p->name); ?>

<?php echo e($p->price); ?>


<?php endforeach; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>