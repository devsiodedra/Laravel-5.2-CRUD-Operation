<html>
<head>
	<title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
<?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('body'); ?>
</body>
</html>