<?php $__env->startSection('title'); ?>
	Create new product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<?php echo Form::open(['route' => 'product.store']); ?>


	<?php echo Form::label('name', 'Name'); ?>

	<?php echo Form::text('name',null,['placeholder' => "Give a name"]); ?>


	<br>

	<?php echo Form::label('price', 'price'); ?>

	<?php echo Form::text('price','$10',['placeholder' => "Give a price"]); ?>

	<?php echo Form::submit('create'); ?>


<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>