<?php $__env->startSection('title'); ?>
    About
<?php $__env->stopSection(); ?>

        <?php $__env->startSection('body'); ?>
        <h1> This is about us page</h1>


        <p><?php echo e($cname); ?></p>

        <?php if($isUserRegistered == false): ?>
           <p> hello welcome..!!</p>
        <?php else: ?>
           <p> please register..!!</p>
        <?php endif; ?>

        <?php for($i = 0; $i < 10; $i++): ?>
          <center> <p> The current value is <?php echo e($i); ?> </p> </center>
        <?php endfor; ?>

        <?php foreach($users as $data): ?>
            <?php echo e($data); ?><br>
        <?php endforeach; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>