<?php $__env->startSection('title'); ?>
Edit<?php echo e($product->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<?php echo Form::model($product,[
	'method' => 'patch',
	'route' => ['product.update',$product->id]
	]); ?>


	<?php echo Form::label('name', 'Name'); ?>

	<?php echo Form::text('name',$product->name,['placeholder' => "Give a name"]); ?>


	<br>

	<?php echo Form::label('price', 'price'); ?>

	<?php echo Form::text('price',$product->price,['placeholder' => "Give a price"]); ?>

	


<?php echo Form::submit('Edit'); ?>

<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>