<?php $__env->startSection('title'); ?>
    Contact us
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <h2>this is contact page</h2>
    <input type="text">
    <?php echo Form::text('price'); ?>

   <?php echo Form::date('name', \Carbon\Carbon::now());; ?>

   <?php echo Form::file('name'); ?>

   <?php echo Form::submit('Click Me!');; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>