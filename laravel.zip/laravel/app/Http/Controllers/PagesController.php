<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

class PagesController extends Controller
{
    public function getIndex()
    {
        return view('welcome');
    }

    public function getHome()
    {
        return view('pages.home');
    }
    
    public function getAbout()
    {
        $cname = "company name";
        $isUserRegistered = false;
        $users = array("dev","jinesh","harshal","hiren","tushar");
        return view('pages.about')
        ->with("cname",$cname)
        ->with("isUserRegistered",$isUserRegistered)
        ->with("users",$users);
    }

    public function getContact()
    {
        return view('pages.contact');
    }
}