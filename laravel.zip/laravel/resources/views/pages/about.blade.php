@extends('layouts.layout')

@section('title')
    About
@stop

        @section('body')
        <h1> This is about us page</h1>


        <p>{{$cname}}</p>

        @if($isUserRegistered == false)
           <p> hello welcome..!!</p>
        @else
           <p> please register..!!</p>
        @endif

        @for ($i = 0; $i < 10; $i++)
          <center> <p> The current value is {{ $i }} </p> </center>
        @endfor

        @foreach($users as $data)
            {{$data}}<br>
        @endforeach
@stop
