@extends('layouts.layout')

@section('title')
    Contact us
@stop

@section('body')
    <h2>this is contact page</h2>
    <input type="text">
    {!! Form::text('price') !!}
   {!! Form::date('name', \Carbon\Carbon::now()); !!}
   {!! Form::file('name') !!}
   {!!Form::submit('Click Me!');!!}
@stop