@extends('layouts.layout')
@section('title')
	Create new product
@stop

@section('body')

{!!Form::open(['route' => 'product.store'])!!}

	{!!Form::label('name', 'Name')!!}
	{!!Form::text('name',null,['placeholder' => "Give a name"])!!}

	<br>

	{!!Form::label('price', 'price')!!}
	{!!Form::text('price','$10',['placeholder' => "Give a price"])!!}
	{!!Form::submit('create')!!}

{!!Form::close()!!}

@stop
