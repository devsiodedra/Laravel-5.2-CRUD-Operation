@extends('layouts.layout')
@section('title')
	All Products
@stop

@section('body')
@foreach($products as $p)
{{$p->name}}
{{$p->price}}

@endforeach
@stop